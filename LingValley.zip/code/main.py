import pygame, sys
from settings import *
from level import Level

# initial window of the game being played
class Game:

	# initializing the game state, title, display
	def __init__(self):
		pygame.init()
		self.screen = pygame.display.set_mode((SCREEN_WIDTH,SCREEN_HEIGHT))
		pygame.display.set_caption('Ling Valley')
		self.clock = pygame.time.Clock()
		self.level = Level()

	# running the window with delta time as input time counter
	def run(self):
		while True:
			for event in pygame.event.get():
				if event.type == pygame.QUIT:
					pygame.quit()
					sys.exit()
  
			dt = self.clock.tick() / 1000
			self.level.run(dt)
			pygame.display.update()

# checking if this is the main class and run the game
if __name__ == '__main__':
	game = Game()
	game.run()