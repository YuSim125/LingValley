Welcome to Ling Valley!

RULES:
    1. Use arrow keys as movement keys around the map.
    2. Pressing Q swaps your current tool found on the bottom left of the screen.
    3. Pressing E swaps the current seed found on the bottom left of the screen
       and on the right of your current tool.
    4. Using the axe:
        Spacebar with the character facing towards trees to chop them down. 
        Trees may contain apples that you can collect. 
        Chopping down a tree gives the player 1 wood.
        A tree stump is formed after a tree has been chopped down.
    5. Using the hoe:
        Spacebar on the ground to create a plot of land that is farmable.
        Making plots of soil next to each other will combine them to become one big plot
    6. Using the water:
        Water the soil parts of the ground by pressing spacebar on a plot of soil.
        There are different water animations.
    7. Interacting with the trader:
    8. Resetting the day:
        Move towards the bed of the players house and face the bed.
        Hit the Enter key for the game to move on to a new day.
        Resetting the day will reset the water on soil and apples on trees.
        Resetting the day when it is raining will put water on all the soil.
        Resetting the day when it is not raining will clear all water from soil.
    9. Weather conditions are random. Some days it will rain, other days it will be sunny.
    10. Planting:
            Based on hitbox, choose a certain seed and press LCTRL on the soil where you want the seed to go. 
            The seed will grow after every day. 
    11. Collecting plants:
            Once the plants are ready to be collected, walk over them to collect them.
    12. Interacting with the trader:
            Press enter to interact with the trader when near their radius. 
            A Menu will pop up allowing you to sell wood/apple/etc for gold.
            The Menu will also allow you to purchase seed items with the gold you currently have. 
            You will be able to see the quantity of what you can purchase and how much of each item you currently have.
            Press ESC to leave menu bar