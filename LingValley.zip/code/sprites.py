import pygame
from settings import *
from random import randint, choice
from timer import Timer

# the variables of the game
class Generic(pygame.sprite.Sprite):

	# initializing the general variable and its parameters
	def __init__(self, pos, surf, groups, z = LAYERS['main']):
		super().__init__(groups)
		self.image = surf
		self.rect = self.image.get_rect(topleft = pos)
		self.z = z
		self.hitbox = self.rect.copy().inflate(-self.rect.width * 0.2, -self.rect.height * 0.75)

# the interactions of the game
class Interaction(Generic):

	# initializing the interactions of the game
	def __init__(self, pos, size, groups, name):
		surf = pygame.Surface(size)
		super().__init__(pos, surf, groups)
		self.name = name

# water variable
class Water(Generic):
	
	# initializing the water frames and animation
	def __init__(self, pos, frames, groups):

		#animation setup
		self.frames = frames
		self.frame_index = 0

		# sprite setup
		super().__init__(
				pos = pos, 
				surf = self.frames[self.frame_index], 
				groups = groups, 
				z = LAYERS['water']) 

	# animating with counter on different pictures
	def animate(self,dt):
		self.frame_index += 5 * dt
		if self.frame_index >= len(self.frames):
			self.frame_index = 0
		self.image = self.frames[int(self.frame_index)]

	# update animation constantly
	def update(self,dt):
		self.animate(dt)

# flower that are on the map
class WildFlower(Generic):

	# initializing the flower surface and hitbox
	def __init__(self, pos, surf, groups):
		super().__init__(pos, surf, groups)
		self.hitbox = self.rect.copy().inflate(-20,-self.rect.height * 0.9)

# trees on the map (large and small)
class Tree(Generic):

	# initializing the tree surface 
	def __init__(self, pos, surf, groups, name, player_add):
		super().__init__(pos, surf, groups)

		
		# apples
		self.apple_surf = pygame.image.load('../graphics/fruit/apple.png')
		self.apple_pos = APPLE_POS[name]
		self.apple_sprites = pygame.sprite.Group()
		self.create_fruit()

		# tree attributes
		self.health = 5
		self.alive = True
		stump_path = f'../graphics/stumps/{"small" if name == "Small" else "large"}.png'
		self.stump_surf = pygame.image.load(stump_path).convert_alpha()


		self.player_add = player_add

		# sounds
		self.axe_sound = pygame.mixer.Sound('../audio/axe.mp3')

	# hitting the tree
	def damage(self):
		
		# damaging the tree
		self.health -= 1

		# play sound
		self.axe_sound.play()

		# remove an apple
		if len(self.apple_sprites.sprites()) > 0:
			random_apple = choice(self.apple_sprites.sprites())
			self.player_add('apple')
			random_apple.kill()

	# seeing if tree is chopped
	def check_death(self):
		if self.health <= 0:
			self.image = self.stump_surf
			self.rect = self.image.get_rect(midbottom = self.rect.midbottom)
			self.hitbox = self.rect.copy().inflate(-10,-self.rect.height * 0.6)
			self.alive = False
			self.player_add('wood')

	# updating tree based on health
	def update(self,dt):
		if self.alive:
			self.check_death()

	# creating apples on tree
	def create_fruit(self):
		for pos in self.apple_pos:
			if randint(0,10) < 2:
				x = pos[0] + self.rect.left
				y = pos[1] + self.rect.top
				Generic(
					pos = (x,y), 
					surf = self.apple_surf, 
					groups = [self.apple_sprites,self.groups()[0]],
					z = LAYERS['fruit'])