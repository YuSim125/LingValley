<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.4" name="Hills" tilewidth="64" tileheight="64" tilecount="36" columns="6">
 <image source="../../graphics/environment/Hills.png" width="384" height="384"/>
</tileset>
